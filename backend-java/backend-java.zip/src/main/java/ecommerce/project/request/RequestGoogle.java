package ecommerce.project.request;

import lombok.Data;

@Data
public class RequestGoogle {
    private String email;
    private String name;
    private String picture;
}
