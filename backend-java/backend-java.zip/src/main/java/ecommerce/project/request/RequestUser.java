package ecommerce.project.request;

import lombok.Data;

@Data
public class RequestUser {
    private String email;
    private String password;
}
