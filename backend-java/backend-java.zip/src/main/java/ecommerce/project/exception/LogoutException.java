package ecommerce.project.exception;

public class LogoutException extends  RuntimeException{
    public LogoutException(String message) {
        super(message);
    }
}
