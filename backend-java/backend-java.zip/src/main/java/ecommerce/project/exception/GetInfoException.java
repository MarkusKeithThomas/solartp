package ecommerce.project.exception;

public class GetInfoException extends RuntimeException{
    public GetInfoException(String message) {
        super(message);
    }
}
