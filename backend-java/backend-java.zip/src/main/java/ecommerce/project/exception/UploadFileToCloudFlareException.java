package ecommerce.project.exception;

public class UploadFileToCloudFlareException extends RuntimeException{
    public UploadFileToCloudFlareException(String message) {
        super(message);
    }
}
