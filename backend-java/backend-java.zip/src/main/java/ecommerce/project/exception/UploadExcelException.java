package ecommerce.project.exception;

public class UploadExcelException extends RuntimeException {
    public UploadExcelException(String message) {
        super(message);
    }
}
