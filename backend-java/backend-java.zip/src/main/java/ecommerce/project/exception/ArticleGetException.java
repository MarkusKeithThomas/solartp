package ecommerce.project.exception;

public class ArticleGetException extends RuntimeException{
    public ArticleGetException(String message) {
        super(message);
    }
}
