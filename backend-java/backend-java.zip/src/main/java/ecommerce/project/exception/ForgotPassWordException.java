package ecommerce.project.exception;

public class ForgotPassWordException extends RuntimeException{
    public ForgotPassWordException(String message) {
        super(message);
    }
}
