package ecommerce.project.exception;

public class RegisterException extends RuntimeException{
    public RegisterException(String message) {
        super(message);
    }
}
