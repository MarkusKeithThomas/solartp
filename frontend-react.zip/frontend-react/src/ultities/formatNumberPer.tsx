export function formatNumberPer(number: number): string {
    return `${Math.round(number)}%`;
}