import "../../styles/custom.css"; // Import CSS tùy chỉnh
export function SolarPanel() {
  return (
    <>
      <h1 className="text-primary text-center fw-bold my-4">
        Điện Mặt Trời Mái Nhà Gia Đình và Hộ Kinh Doanh
      </h1>
      <div className=" bg-light text-dark rounded shadow-sm p-1">
      <p className="fs-5 text-justify">
      Điện mặt trời mái nhà không chỉ giúp tiết kiệm hóa đơn điện mỗi tháng
          mà còn là bước đi thông minh trong thời đại năng lượng xanh.{" "}
        </p>
      </div>
    </>
  );
}
